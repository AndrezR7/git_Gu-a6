package javaapplicationhilos;

public class HiloPersonalizado extends Thread {
     private String nombreHilo;

    HiloPersonalizado(String nombre) {
        this.nombreHilo = nombre;
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(nombreHilo + " está en el ciclo " + i);
            try {
                // Dormir el hilo por X segundo
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                System.out.println(nombreHilo + " ha sido interrumpido.");
            }
        }
    }
}
