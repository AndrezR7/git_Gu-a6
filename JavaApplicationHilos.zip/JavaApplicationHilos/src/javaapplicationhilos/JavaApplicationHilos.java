
package javaapplicationhilos;
import javaapplicationhilos.HiloPersonalizado;

public class JavaApplicationHilos {

    public static void main(String[] args) {
        // Crear hilos
        Thread hilo1 = new HiloPersonalizado("Hilo 1");
        Thread hilo2 = new HiloPersonalizado("Hilo 2");
        
        // Iniciar hilos
        hilo1.start();
        hilo2.start();
    }
    
   
    
}
